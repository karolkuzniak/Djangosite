from django.db import models


class Product(models.Model):  # Singular form for the model name
    name = models.CharField(max_length=255)  # Corrected spelling
    price = models.FloatField()
    stock = models.IntegerField()
    image_url = models.CharField(max_length=2083)  # Corrected spelling


class Offer(models.Model):
    code = models.CharField(max_length=10)
    description = models.CharField(max_length=255)
    discount = models.FloatField()

